var classctre_1_1phoenix_1_1_c_a_nifier =
[
    [ "PinValues", "structctre_1_1phoenix_1_1_c_a_nifier_1_1_pin_values.html", "structctre_1_1phoenix_1_1_c_a_nifier_1_1_pin_values" ],
    [ "GeneralPin", "classctre_1_1phoenix_1_1_c_a_nifier.html#a19500f07bc0811a9da0993ff664eface", [
      [ "QUAD_IDX", "classctre_1_1phoenix_1_1_c_a_nifier.html#a19500f07bc0811a9da0993ff664efaceac9d0ada4f8fd1c7dbef51d08c8f69203", null ],
      [ "QUAD_B", "classctre_1_1phoenix_1_1_c_a_nifier.html#a19500f07bc0811a9da0993ff664efaceabd42a958368b83f5dfe39b96477f9bed", null ],
      [ "QUAD_A", "classctre_1_1phoenix_1_1_c_a_nifier.html#a19500f07bc0811a9da0993ff664efacea205faff806dcfcbe6a4eb9c1ff9befa9", null ],
      [ "LIMR", "classctre_1_1phoenix_1_1_c_a_nifier.html#a19500f07bc0811a9da0993ff664efacea0ff0307ecf659b02b3bb86730c3a38e6", null ],
      [ "LIMF", "classctre_1_1phoenix_1_1_c_a_nifier.html#a19500f07bc0811a9da0993ff664efacea4e216c9380bbbaa732b264b919878e5f", null ],
      [ "SDA", "classctre_1_1phoenix_1_1_c_a_nifier.html#a19500f07bc0811a9da0993ff664efaceab3def09f82ae0b229e966df5c2d11a3f", null ],
      [ "SCL", "classctre_1_1phoenix_1_1_c_a_nifier.html#a19500f07bc0811a9da0993ff664efaceaa360ea8d8c39de4b61a2971332732670", null ],
      [ "SPI_CS", "classctre_1_1phoenix_1_1_c_a_nifier.html#a19500f07bc0811a9da0993ff664efaceab57b38e73926ce356f0260f6109cf7aa", null ],
      [ "SPI_MISO_PWM2P", "classctre_1_1phoenix_1_1_c_a_nifier.html#a19500f07bc0811a9da0993ff664efacea752005f79c9ff271abbd2029f5fb928f", null ],
      [ "SPI_MOSI_PWM1P", "classctre_1_1phoenix_1_1_c_a_nifier.html#a19500f07bc0811a9da0993ff664efacea0bb2891848b1761293cf890bfc48193b", null ],
      [ "SPI_CLK_PWM0P", "classctre_1_1phoenix_1_1_c_a_nifier.html#a19500f07bc0811a9da0993ff664efacea64af2cd0e72739d95a8be160b2001497", null ]
    ] ],
    [ "LEDChannel", "classctre_1_1phoenix_1_1_c_a_nifier.html#a830045cce4d3bf8a08a1da76b8a703ec", [
      [ "LEDChannelA", "classctre_1_1phoenix_1_1_c_a_nifier.html#a830045cce4d3bf8a08a1da76b8a703eca9de2a81db28ecac8c704396625813f41", null ],
      [ "LEDChannelB", "classctre_1_1phoenix_1_1_c_a_nifier.html#a830045cce4d3bf8a08a1da76b8a703ecad67a213353466d9aa4de58b870c6ad13", null ],
      [ "LEDChannelC", "classctre_1_1phoenix_1_1_c_a_nifier.html#a830045cce4d3bf8a08a1da76b8a703eca58af31705a91c257ccd69a4b61374ffa", null ]
    ] ],
    [ "PWMChannel", "classctre_1_1phoenix_1_1_c_a_nifier.html#a5a487852ca0ff4079eb720f89903835d", [
      [ "PWMChannel0", "classctre_1_1phoenix_1_1_c_a_nifier.html#a5a487852ca0ff4079eb720f89903835da1599d6918778f9e762d49c192d43ea5f", null ],
      [ "PWMChannel1", "classctre_1_1phoenix_1_1_c_a_nifier.html#a5a487852ca0ff4079eb720f89903835da4cf7bb46b926000c4f57958f44f014d3", null ],
      [ "PWMChannel2", "classctre_1_1phoenix_1_1_c_a_nifier.html#a5a487852ca0ff4079eb720f89903835daebd352832ad7af00194cd2cf61736720", null ],
      [ "PWMChannel3", "classctre_1_1phoenix_1_1_c_a_nifier.html#a5a487852ca0ff4079eb720f89903835da293bead52dbc33585a641d65db46fd86", null ]
    ] ],
    [ "CANifier", "classctre_1_1phoenix_1_1_c_a_nifier.html#a706308fce1dea96785bf3ac845bafc02", null ],
    [ "ClearStickyFaults", "classctre_1_1phoenix_1_1_c_a_nifier.html#a8d07f271067b531bb30322f410625494", null ],
    [ "ConfigGetCustomParam", "classctre_1_1phoenix_1_1_c_a_nifier.html#a8a3fd27cc2ca6583c26000e4fbbcbfb7", null ],
    [ "ConfigGetParameter", "classctre_1_1phoenix_1_1_c_a_nifier.html#ad0e53a763d91c5dc4ae465b66eda57a2", null ],
    [ "ConfigSetCustomParam", "classctre_1_1phoenix_1_1_c_a_nifier.html#aa0ed368cd44c8c564d4ffdec37fbd95d", null ],
    [ "ConfigSetParameter", "classctre_1_1phoenix_1_1_c_a_nifier.html#a249ad515fa5acd09b162142a06e56d39", null ],
    [ "EnablePWMOutput", "classctre_1_1phoenix_1_1_c_a_nifier.html#aeceff0ea74d26f3a6b830e870e59c279", null ],
    [ "GetBusVoltage", "classctre_1_1phoenix_1_1_c_a_nifier.html#ac72786465b9bde9c32e12b9587a2df93", null ],
    [ "GetFaults", "classctre_1_1phoenix_1_1_c_a_nifier.html#a4e07aa9b1a139dce3b425950c8665e14", null ],
    [ "GetFirmwareVersion", "classctre_1_1phoenix_1_1_c_a_nifier.html#afe1a39fbdd58e3c4198a04083112f77f", null ],
    [ "GetGeneralInput", "classctre_1_1phoenix_1_1_c_a_nifier.html#a2dca463f6920cb54becca85765f81b39", null ],
    [ "GetGeneralInputs", "classctre_1_1phoenix_1_1_c_a_nifier.html#a8964ff8b592381812238eef27717eb43", null ],
    [ "GetLastError", "classctre_1_1phoenix_1_1_c_a_nifier.html#ab6f4c4a5613480d54bc9c8be17e348b8", null ],
    [ "GetPWMInput", "classctre_1_1phoenix_1_1_c_a_nifier.html#a44c70ae10c17fd08c4f32b4107f652d2", null ],
    [ "GetStatusFramePeriod", "classctre_1_1phoenix_1_1_c_a_nifier.html#a64dadca38d6436f8c5e9d7a593eaf8a7", null ],
    [ "GetStickyFaults", "classctre_1_1phoenix_1_1_c_a_nifier.html#ad9432c5acf6c9670508f5fc0d5c4c4ab", null ],
    [ "HasResetOccurred", "classctre_1_1phoenix_1_1_c_a_nifier.html#a32583a2821847249804cf06ef0491e52", null ],
    [ "SetControlFramePeriod", "classctre_1_1phoenix_1_1_c_a_nifier.html#ae687df14bec36308cf0e59fce9b62fa1", null ],
    [ "SetGeneralOutput", "classctre_1_1phoenix_1_1_c_a_nifier.html#aa17acbbebcbbcb3a1a63873ee23a8a4b", null ],
    [ "SetGeneralOutputs", "classctre_1_1phoenix_1_1_c_a_nifier.html#ac2ff20c04a75163d8d10cc08685635b0", null ],
    [ "SetLEDOutput", "classctre_1_1phoenix_1_1_c_a_nifier.html#a97d6f6ccaad0307f9024acde96fe119e", null ],
    [ "SetPWMOutput", "classctre_1_1phoenix_1_1_c_a_nifier.html#aa165b671c82ca3a39f5866af12bb7dfe", null ],
    [ "SetStatusFramePeriod", "classctre_1_1phoenix_1_1_c_a_nifier.html#a7db0e2984de328d1b14458a4271e86fc", null ],
    [ "PWMChannelCount", "classctre_1_1phoenix_1_1_c_a_nifier.html#a9db86680809cb89fdfe0fc7632a8768e", null ]
];