var classctre_1_1phoenix_1_1tasking_1_1_button_monitor_1_1_i_button_press_event_handler =
[
    [ "~IButtonPressEventHandler", "classctre_1_1phoenix_1_1tasking_1_1_button_monitor_1_1_i_button_press_event_handler.html#ab2015cd2f0e2362af10fd808db21739d", null ],
    [ "OnButtonPress", "classctre_1_1phoenix_1_1tasking_1_1_button_monitor_1_1_i_button_press_event_handler.html#aa710c77530f53021562822b895cd0469", null ]
];