var annotated_dup =
[
    [ "ctre", "namespacectre.html", "namespacectre" ],
    [ "CANBusAddressable", "class_c_a_n_bus_addressable.html", "class_c_a_n_bus_addressable" ],
    [ "Device_LowLevel", "class_device___low_level.html", "class_device___low_level" ],
    [ "IGadgeteerUartClient", "class_i_gadgeteer_uart_client.html", "class_i_gadgeteer_uart_client" ],
    [ "LoggerDriver", "class_logger_driver.html", "class_logger_driver" ],
    [ "LowLevelCANifier", "class_low_level_c_a_nifier.html", "class_low_level_c_a_nifier" ],
    [ "LowLevelPigeonImu", "class_low_level_pigeon_imu.html", "class_low_level_pigeon_imu" ],
    [ "ResetStats", "struct_reset_stats.html", "struct_reset_stats" ]
];