var searchData=
[
  ['velocitymeasperiod',['VelocityMeasPeriod',['../namespacectre_1_1phoenix_1_1motorcontrol.html#ac7b007d595c8fa57b817fa56f88ee73c',1,'ctre::phoenix::motorcontrol']]]
];
